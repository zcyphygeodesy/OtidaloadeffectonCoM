地球质心变化海潮负荷效应预报算法Fortran代码
https://www.zcyphygeodesy.com/h-nd-127.html

[计算目标]
    输入时间序列参数，由海潮负荷球谐系数一阶项文件（ETideLoad4.5海潮负荷球谐系数模型构建程序输出文件），预报地球质心变化的海潮负荷效应（Xcm, Ycm, Zcm；mm）时间序列。
    改善IERS2010地球质心负荷潮效应算法，使得地球质心变化负荷潮效应与全球负荷潮球谐系数模型严格一一对应。
    地球质心处天体的引潮力恒等于零，大地测量学因此不具体研究固体潮产生的地球质心变化。海洋潮汐、地面大气压潮分别导致海水质量和大气密度的重新分布，引起地球质心周期性变化。
[输入地球物理模型文件]
 （1）海潮负荷球谐系数一阶项文件OtideOne.dat。
    由[海潮负荷球谐系数模型构建程序]生成，可通过ETideLoad4.5[地球物理模型与数值标准设置]程序中更新。

[测试入口程序]
    OceantidaloadeffCoM.f90
    输出文件reslt.txt记录：长整型ETideLoad格式时间，相对开始时间的天数（实数），地球质心变化的海潮负荷效应xx, yy, zz（mm）。
[调用模块]
 （1）海洋分潮相位偏差计算模块
    BiasTide(doodson,bias)
    输入doodson(6)－分潮Doodson参数（整数）。
    返回th－分潮的相位偏差（度）。
 （2）海洋分潮天文幅角计算模块
    Argutheta(mjd,doodson,th)
    输入mjd－预报时刻（MJD天）。
    返回th－mjd时刻分潮的天文幅角（弧度）。
 （3）大地坐标变换包
    BLH_RLAT(GRS, BLH, RLAT)；BLH_XYZ(GRS, BLH, XYZ)
    RLAT_BLH(GRS, RLAT, BLH)
 （4）时间系统转换包
    CAL2JD (IY0, IM0, ID0, DJM, J)；JD2CAL(DJ1, DJ2, IY, IM, ID, FD, J)
 （5）其他辅助模块
    PickRecord(str0, kln, rec, nn)；tmcnt(tm, iyr, imo, idy, ihr, imn, sec)
    mjdtotm(mjd0, ltm)；tmtostr(tm, tmstr)

[编译连接]
    Fortran固定格式代码，任何fortran编译器，无需任何外部连接库。
[算法公式]参见ETideLoad4.5参考说明书（https://www.zcyphygeodesy.com）
    8.5.1.1地球质心位置潮汐效应预报计算

DOS可执行测试程序、地球物理模型和全部测试输入输出数据。
